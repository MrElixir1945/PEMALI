"use client";

import { useCallback, useRef } from "react";
import { useTelemetryStore } from "@/store/telemetryStore";
import { TelemetryEvent, TokenEvent } from "@/types/pemali";

export function useSSEStream() {
  const abortRef = useRef<AbortController | null>(null);
  const { addEvent, addToken, setConnected, setIsStreaming, clearTokens } =
    useTelemetryStore();

  const startStream = useCallback(
    async (userMessage: string) => {
      // Abort any existing stream
      if (abortRef.current) {
        abortRef.current.abort();
      }

      const controller = new AbortController();
      abortRef.current = controller;

      setConnected(true);
      setIsStreaming(true);
      clearTokens();

      try {
        const res = await fetch("/api/stream", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: userMessage }),
          signal: controller.signal,
        });

        if (!res.ok || !res.body) {
          throw new Error(`HTTP ${res.status}`);
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          let eventType = "";
          let dataLine = "";

          for (const line of lines) {
            if (line.startsWith("event:")) {
              eventType = line.slice(6).trim();
            } else if (line.startsWith("data:")) {
              dataLine = line.slice(5).trim();
            } else if (line === "" && dataLine) {
              try {
                const parsed = JSON.parse(dataLine);
                if (eventType === "state") {
                  addEvent(parsed as TelemetryEvent);
                } else if (eventType === "token") {
                  const t = parsed as TokenEvent;
                  addToken(t.node_id, t.content);
                }
              } catch {
                // malformed JSON, skip
              }
              eventType = "";
              dataLine = "";
            }
          }
        }
      } catch (err: unknown) {
        if ((err as Error)?.name !== "AbortError") {
          console.error("SSE stream error:", err);
        }
      } finally {
        setConnected(false);
        setIsStreaming(false);
      }
    },
    [addEvent, addToken, setConnected, setIsStreaming, clearTokens]
  );

  const stopStream = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
  }, [setIsStreaming]);

  return { startStream, stopStream };
}
