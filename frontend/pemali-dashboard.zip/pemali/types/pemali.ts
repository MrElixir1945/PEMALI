// ─── SSE Event Types ───────────────────────────────────────────────────────

export type NodeType = "Manager" | "SubAgent" | "Module";

export type NodeState =
  | "IDLE"
  | "THINKING"
  | "SPAWNING"
  | "EXECUTING"
  | "DONE"
  | "ERROR";

export interface TelemetryEvent {
  trace_id: string;
  node_id: string;
  node_type: NodeType;
  state: NodeState;
  narrative: string;
  timestamp: number;
  metadata: Record<string, unknown> | null;
}

export interface TokenEvent {
  node_id: string;
  content: string;
}

// ─── Graph Types ────────────────────────────────────────────────────────────

export interface AgentNodeData {
  id: string;
  node_type: NodeType;
  state: NodeState;
  narrative: string;
  metadata: Record<string, unknown> | null;
  timestamp: number;
  x: number;
  y: number;
}

export interface GraphEdge {
  from: string;
  to: string;
  id: string;
}

// ─── Session Types ──────────────────────────────────────────────────────────

export interface Session {
  id: string;
  label: string;
  timestamp: number;
  traceId: string | null;
  status: "active" | "done" | "error";
}
