"use client";

import React, { useMemo } from "react";
import { useTelemetryStore } from "@/store/telemetryStore";
import { NodeState } from "@/types/pemali";

const STATE_COLORS: Record<NodeState, string> = {
  IDLE: "#9B9690",
  THINKING: "#D4956A",
  SPAWNING: "#8A9598",
  EXECUTING: "#7A9A78",
  DONE: "#80A888",
  ERROR: "#B07068",
};

export default function NodeDetailPanel() {
  const events = useTelemetryStore((s) => s.events);
  const selectedNodeId = useTelemetryStore((s) => s.selectedNodeId);
  const setSelectedNodeId = useTelemetryStore((s) => s.setSelectedNodeId);

  const nodeEvents = useMemo(
    () =>
      events
        .filter((e) => e.node_id === selectedNodeId)
        .slice()
        .reverse(),
    [events, selectedNodeId]
  );

  const latestEvent = nodeEvents[0];

  if (!selectedNodeId || !latestEvent) {
    return (
      <div
        style={{
          padding: "16px",
          color: "var(--pemali-text-muted)",
          fontSize: 11,
          fontFamily: "var(--font-geist-mono, monospace)",
          textAlign: "center",
          paddingTop: 32,
        }}
      >
        Klik node untuk detail
      </div>
    );
  }

  const stateColor = STATE_COLORS[latestEvent.state] ?? "#9B9690";

  return (
    <div style={{ padding: "14px 16px", overflow: "auto", maxHeight: "100%" }}>
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          marginBottom: 12,
        }}
      >
        <div>
          <div
            style={{
              fontSize: 12,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: "var(--pemali-text-primary)",
              fontWeight: 700,
              marginBottom: 3,
            }}
          >
            {latestEvent.node_id}
          </div>
          <div
            style={{
              fontSize: 10,
              color: "var(--pemali-text-muted)",
              fontFamily: "var(--font-geist-mono, monospace)",
              letterSpacing: "0.05em",
            }}
          >
            {latestEvent.node_type.toUpperCase()}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            style={{
              fontSize: 10,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: stateColor,
              background: `${stateColor}18`,
              padding: "3px 7px",
              borderRadius: 3,
              fontWeight: 700,
            }}
          >
            {latestEvent.state}
          </span>
          <button
            onClick={() => setSelectedNodeId(null)}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "var(--pemali-text-muted)",
              fontSize: 14,
              lineHeight: 1,
              padding: "2px 4px",
              borderRadius: 3,
            }}
          >
            ✕
          </button>
        </div>
      </div>

      {/* Divider */}
      <div
        style={{
          height: 1,
          background: "var(--pemali-border)",
          marginBottom: 12,
        }}
      />

      {/* Latest narrative */}
      <div style={{ marginBottom: 12 }}>
        <div
          style={{
            fontSize: 9,
            color: "var(--pemali-text-muted)",
            fontFamily: "var(--font-geist-mono, monospace)",
            letterSpacing: "0.08em",
            marginBottom: 6,
          }}
        >
          NARASI TERKINI
        </div>
        <p
          style={{
            fontSize: 12,
            lineHeight: 1.65,
            color: "var(--pemali-text-primary)",
            margin: 0,
            whiteSpace: "pre-wrap",
          }}
        >
          {latestEvent.narrative}
        </p>
      </div>

      {/* Metadata */}
      {latestEvent.metadata && (
        <>
          <div
            style={{
              height: 1,
              background: "var(--pemali-border)",
              marginBottom: 10,
            }}
          />
          <div style={{ marginBottom: 12 }}>
            <div
              style={{
                fontSize: 9,
                color: "var(--pemali-text-muted)",
                fontFamily: "var(--font-geist-mono, monospace)",
                letterSpacing: "0.08em",
                marginBottom: 6,
              }}
            >
              METADATA
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {Object.entries(latestEvent.metadata).map(([k, v]) => (
                <div
                  key={k}
                  style={{ display: "flex", gap: 8, alignItems: "baseline" }}
                >
                  <span
                    style={{
                      fontSize: 10,
                      fontFamily: "var(--font-geist-mono, monospace)",
                      color: "var(--pemali-text-muted)",
                      minWidth: 80,
                    }}
                  >
                    {k}
                  </span>
                  <span
                    style={{
                      fontSize: 10,
                      fontFamily: "var(--font-geist-mono, monospace)",
                      color:
                        k === "error" || k === "status" && v === "error"
                          ? "#B07068"
                          : k === "duration_ms"
                          ? "#7A9A78"
                          : "var(--pemali-text-secondary)",
                    }}
                  >
                    {String(v)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Event history (compact) */}
      {nodeEvents.length > 1 && (
        <>
          <div
            style={{
              height: 1,
              background: "var(--pemali-border)",
              marginBottom: 10,
            }}
          />
          <div>
            <div
              style={{
                fontSize: 9,
                color: "var(--pemali-text-muted)",
                fontFamily: "var(--font-geist-mono, monospace)",
                letterSpacing: "0.08em",
                marginBottom: 6,
              }}
            >
              RIWAYAT ({nodeEvents.length})
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {nodeEvents.slice(0, 6).map((ev, i) => (
                <div
                  key={i}
                  style={{
                    display: "flex",
                    gap: 8,
                    alignItems: "center",
                    padding: "4px 6px",
                    borderRadius: 4,
                    background: i === 0 ? "rgba(212,149,106,0.05)" : "transparent",
                  }}
                >
                  <span
                    style={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      background: STATE_COLORS[ev.state] ?? "#9B9690",
                      flexShrink: 0,
                    }}
                  />
                  <span
                    style={{
                      fontSize: 9,
                      fontFamily: "var(--font-geist-mono, monospace)",
                      color: STATE_COLORS[ev.state] ?? "#9B9690",
                      minWidth: 64,
                    }}
                  >
                    {ev.state}
                  </span>
                  <span
                    style={{
                      fontSize: 10,
                      color: "var(--pemali-text-muted)",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {new Date(ev.timestamp * 1000).toLocaleTimeString("id-ID")}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
