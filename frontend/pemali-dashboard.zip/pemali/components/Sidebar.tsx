"use client";

import React, { useState } from "react";
import { useTelemetryStore } from "@/store/telemetryStore";
import { Session } from "@/types/pemali";

const STATUS_CONFIG: Record<
  Session["status"],
  { color: string; icon: string }
> = {
  active: { color: "#D4956A", icon: "◎" },
  done: { color: "#80A888", icon: "✓" },
  error: { color: "#B07068", icon: "✕" },
};

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  const hr = Math.floor(diff / 3600000);
  if (min < 1) return "baru saja";
  if (min < 60) return `${min}m lalu`;
  if (hr < 24) return `${hr}j lalu`;
  return new Date(ts).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
  });
}

export default function Sidebar({
  isOpen,
  onToggle,
}: {
  isOpen: boolean;
  onToggle: () => void;
}) {
  const sessions = useTelemetryStore((s) => s.sessions);
  const activeSessionId = useTelemetryStore((s) => s.activeSessionId);
  const createSession = useTelemetryStore((s) => s.createSession);
  const setActiveSession = useTelemetryStore((s) => s.setActiveSession);
  const clearEvents = useTelemetryStore((s) => s.clearEvents);
  const [newAuditInput, setNewAuditInput] = useState(false);
  const [auditLabel, setAuditLabel] = useState("");

  const handleNewAudit = () => {
    const label = auditLabel.trim() || `Audit ${new Date().toLocaleString("id-ID", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}`;
    createSession(label);
    setNewAuditInput(false);
    setAuditLabel("");
  };

  return (
    <div
      style={{
        width: isOpen ? 216 : 48,
        flexShrink: 0,
        borderRight: "1px solid var(--pemali-border)",
        display: "flex",
        flexDirection: "column",
        transition: "width 0.25s cubic-bezier(0.4,0,0.2,1)",
        overflow: "hidden",
        background: "var(--pemali-bg)",
      }}
    >
      {/* Toggle button */}
      <div
        style={{
          padding: "12px",
          display: "flex",
          justifyContent: isOpen ? "flex-end" : "center",
          borderBottom: "1px solid var(--pemali-border)",
          flexShrink: 0,
        }}
      >
        <button
          onClick={onToggle}
          title={isOpen ? "Tutup sidebar" : "Buka sidebar"}
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            color: "var(--pemali-text-muted)",
            fontSize: 16,
            padding: "4px 6px",
            borderRadius: 5,
            lineHeight: 1,
            transition: "color 0.15s ease",
          }}
        >
          {isOpen ? "←" : "→"}
        </button>
      </div>

      {/* Sidebar content */}
      <div
        style={{
          flex: 1,
          overflow: isOpen ? "auto" : "hidden",
          opacity: isOpen ? 1 : 0,
          transition: "opacity 0.2s ease",
          display: "flex",
          flexDirection: "column",
          gap: 0,
        }}
      >
        {/* New Audit button */}
        <div style={{ padding: "12px 12px 8px 12px", flexShrink: 0 }}>
          {!newAuditInput ? (
            <button
              onClick={() => setNewAuditInput(true)}
              style={{
                width: "100%",
                padding: "8px 10px",
                background: "var(--pemali-accent)",
                border: "none",
                borderRadius: 7,
                color: "#fff",
                fontSize: 11,
                fontWeight: 600,
                fontFamily: "var(--font-geist-mono, monospace)",
                letterSpacing: "0.04em",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 6,
                justifyContent: "center",
                transition: "opacity 0.15s ease",
              }}
            >
              <span>+</span> Audit Baru
            </button>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
              <input
                autoFocus
                value={auditLabel}
                onChange={(e) => setAuditLabel(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleNewAudit();
                  if (e.key === "Escape") {
                    setNewAuditInput(false);
                    setAuditLabel("");
                  }
                }}
                placeholder="Label audit..."
                style={{
                  width: "100%",
                  padding: "7px 9px",
                  background: "var(--pemali-surface)",
                  border: "1px solid var(--pemali-accent)",
                  borderRadius: 6,
                  fontSize: 11,
                  color: "var(--pemali-text-primary)",
                  fontFamily: "inherit",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
              <div style={{ display: "flex", gap: 5 }}>
                <button
                  onClick={handleNewAudit}
                  style={{
                    flex: 1,
                    padding: "5px",
                    background: "var(--pemali-accent)",
                    border: "none",
                    borderRadius: 5,
                    color: "#fff",
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "var(--font-geist-mono, monospace)",
                  }}
                >
                  Mulai
                </button>
                <button
                  onClick={() => {
                    setNewAuditInput(false);
                    setAuditLabel("");
                  }}
                  style={{
                    padding: "5px 8px",
                    background: "none",
                    border: "1px solid var(--pemali-border)",
                    borderRadius: 5,
                    color: "var(--pemali-text-muted)",
                    fontSize: 10,
                    cursor: "pointer",
                  }}
                >
                  Batal
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Session list */}
        <div style={{ flex: 1, overflow: "auto" }}>
          {sessions.length === 0 && (
            <div
              style={{
                padding: "20px 12px",
                fontSize: 10,
                color: "var(--pemali-text-muted)",
                fontFamily: "var(--font-geist-mono, monospace)",
                textAlign: "center",
                lineHeight: 1.8,
              }}
            >
              Belum ada sesi audit
            </div>
          )}
          {sessions.map((session) => {
            const statusCfg = STATUS_CONFIG[session.status];
            const isActive = session.id === activeSessionId;
            return (
              <div
                key={session.id}
                onClick={() => setActiveSession(session.id)}
                style={{
                  padding: "9px 12px",
                  cursor: "pointer",
                  background: isActive
                    ? "rgba(212,149,106,0.06)"
                    : "transparent",
                  borderLeft: isActive
                    ? "2px solid var(--pemali-accent)"
                    : "2px solid transparent",
                  transition: "all 0.15s ease",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    marginBottom: 2,
                  }}
                >
                  <span style={{ fontSize: 9, color: statusCfg.color }}>
                    {statusCfg.icon}
                  </span>
                  <span
                    style={{
                      fontSize: 11,
                      color: isActive
                        ? "var(--pemali-text-primary)"
                        : "var(--pemali-text-secondary)",
                      fontWeight: isActive ? 600 : 400,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      flex: 1,
                    }}
                  >
                    {session.label}
                  </span>
                </div>
                <div
                  style={{
                    fontSize: 9,
                    color: "var(--pemali-text-muted)",
                    fontFamily: "var(--font-geist-mono, monospace)",
                    paddingLeft: 15,
                  }}
                >
                  {formatRelative(session.timestamp)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Collapsed icon */}
      {!isOpen && (
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            paddingTop: 16,
            gap: 10,
          }}
        >
          {sessions.slice(0, 5).map((s) => {
            const cfg = STATUS_CONFIG[s.status];
            return (
              <div
                key={s.id}
                title={s.label}
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background:
                    s.id === activeSessionId ? cfg.color : "var(--pemali-border)",
                  cursor: "pointer",
                  transition: "background 0.15s ease",
                }}
                onClick={onToggle}
              />
            );
          })}
          {sessions.length === 0 && (
            <span
              style={{
                fontSize: 14,
                color: "var(--pemali-text-muted)",
                opacity: 0.4,
              }}
            >
              ⬡
            </span>
          )}
        </div>
      )}
    </div>
  );
}
