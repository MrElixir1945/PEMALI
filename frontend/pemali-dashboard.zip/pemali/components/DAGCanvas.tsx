"use client";

import React, { useMemo, useCallback } from "react";
import { useTelemetryStore } from "@/store/telemetryStore";
import { TelemetryEvent, AgentNodeData, GraphEdge, NodeState } from "@/types/pemali";

// ─── Dagre-lite layout (manual, no npm needed) ──────────────────────────────
// We implement a simple top-down rank layout without dagre dependency
// Manager (rank 0) → SubAgents (rank 1) → Modules (rank 2)

const NODE_W = 232;
const NODE_H = 112;
const RANK_GAP = 90;
const NODE_GAP = 24;

function computeLayout(
  nodes: Omit<AgentNodeData, "x" | "y">[]
): AgentNodeData[] {
  const byRank: Record<number, Omit<AgentNodeData, "x" | "y">[]> = {
    0: [],
    1: [],
    2: [],
  };
  for (const n of nodes) {
    if (n.node_type === "Manager") byRank[0].push(n);
    else if (n.node_type === "SubAgent") byRank[1].push(n);
    else byRank[2].push(n);
  }

  const result: AgentNodeData[] = [];
  const rankOffsets = [0, NODE_H + RANK_GAP, (NODE_H + RANK_GAP) * 2];

  for (let rank = 0; rank <= 2; rank++) {
    const group = byRank[rank];
    const totalW = group.length * NODE_W + (group.length - 1) * NODE_GAP;
    const startX = -totalW / 2 + NODE_W / 2;
    group.forEach((n, i) => {
      result.push({
        ...n,
        x: startX + i * (NODE_W + NODE_GAP),
        y: rankOffsets[rank],
      });
    });
  }
  return result;
}

function buildGraph(events: TelemetryEvent[]): {
  nodes: AgentNodeData[];
  edges: GraphEdge[];
} {
  const nodeMap = new Map<string, Omit<AgentNodeData, "x" | "y">>();
  const edgeSet = new Set<string>();
  const edges: GraphEdge[] = [];
  let lastSubAgent: string | null = null;

  for (const ev of events) {
    const existing = nodeMap.get(ev.node_id);
    if (!existing || ev.timestamp >= (existing.timestamp ?? 0)) {
      nodeMap.set(ev.node_id, {
        id: ev.node_id,
        node_type: ev.node_type,
        state: ev.state,
        narrative: ev.narrative,
        metadata: ev.metadata,
        timestamp: ev.timestamp,
      });
    }

    // Track edges
    if (ev.node_type === "Manager" && ev.state === "SPAWNING") {
      // Edges will be created when SubAgents appear
    }
    if (ev.node_type === "SubAgent") {
      const edgeKey = `manager→${ev.node_id}`;
      if (!edgeSet.has(edgeKey)) {
        edgeSet.add(edgeKey);
        edges.push({ from: "manager", to: ev.node_id, id: edgeKey });
      }
      if (ev.state === "EXECUTING" || ev.state === "THINKING") {
        lastSubAgent = ev.node_id;
      }
    }
    if (ev.node_type === "Module" && lastSubAgent) {
      const edgeKey = `${lastSubAgent}→${ev.node_id}`;
      if (!edgeSet.has(edgeKey)) {
        edgeSet.add(edgeKey);
        edges.push({ from: lastSubAgent, to: ev.node_id, id: edgeKey });
      }
    }
  }

  const rawNodes = Array.from(nodeMap.values());
  const nodes = computeLayout(rawNodes);
  return { nodes, edges };
}

// ─── State colors ────────────────────────────────────────────────────────────
const STATE_CONFIG: Record<
  NodeState,
  { color: string; bg: string; pulse: boolean; icon: string }
> = {
  IDLE: {
    color: "#9B9690",
    bg: "rgba(155,150,144,0.10)",
    pulse: false,
    icon: "○",
  },
  THINKING: {
    color: "#D4956A",
    bg: "rgba(212,149,106,0.12)",
    pulse: true,
    icon: "◎",
  },
  SPAWNING: {
    color: "#8A9598",
    bg: "rgba(138,149,152,0.12)",
    pulse: true,
    icon: "◈",
  },
  EXECUTING: {
    color: "#7A9A78",
    bg: "rgba(122,154,120,0.12)",
    pulse: true,
    icon: "▶",
  },
  DONE: {
    color: "#80A888",
    bg: "rgba(128,168,136,0.10)",
    pulse: false,
    icon: "✓",
  },
  ERROR: {
    color: "#B07068",
    bg: "rgba(176,112,104,0.12)",
    pulse: false,
    icon: "✕",
  },
};

const NODE_TYPE_ICON: Record<string, string> = {
  Manager: "⬡",
  SubAgent: "◆",
  Module: "▪",
};

// ─── AgentNode subcomponent ───────────────────────────────────────────────────
function AgentNode({
  node,
  isSelected,
  onClick,
}: {
  node: AgentNodeData;
  isSelected: boolean;
  onClick: () => void;
}) {
  const cfg = STATE_CONFIG[node.state] ?? STATE_CONFIG.IDLE;
  const truncated =
    node.narrative.length > 90
      ? node.narrative.slice(0, 90) + "…"
      : node.narrative;

  return (
    <div
      onClick={onClick}
      style={{
        position: "absolute",
        left: node.x - NODE_W / 2,
        top: node.y,
        width: NODE_W,
        height: NODE_H,
        background: isSelected
          ? `rgba(212,149,106,0.08)`
          : "var(--pemali-surface)",
        border: `1px solid ${isSelected ? "var(--pemali-accent)" : "var(--pemali-border)"}`,
        borderRadius: 10,
        padding: "12px 14px",
        cursor: "pointer",
        boxShadow: isSelected
          ? "0 0 0 2px rgba(212,149,106,0.25), 0 4px 20px rgba(0,0,0,0.08)"
          : "0 1px 4px rgba(0,0,0,0.06)",
        transition: "all 0.2s ease",
        overflow: "hidden",
      }}
    >
      {/* Pulse ring for active states */}
      {cfg.pulse && (
        <span
          style={{
            position: "absolute",
            inset: -1,
            borderRadius: 10,
            border: `1.5px solid ${cfg.color}`,
            opacity: 0.5,
            animation: "pemali-pulse 1.8s ease-in-out infinite",
            pointerEvents: "none",
          }}
        />
      )}

      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 7,
          marginBottom: 8,
        }}
      >
        <span style={{ fontSize: 13, color: "var(--pemali-text-muted)" }}>
          {NODE_TYPE_ICON[node.node_type] || "◇"}
        </span>
        <span
          style={{
            fontSize: 11,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-secondary)",
            fontWeight: 600,
            letterSpacing: "0.03em",
          }}
        >
          {node.id}
        </span>
        <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: 9, color: cfg.color }}>{cfg.icon}</span>
          <span
            style={{
              fontSize: 9,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: cfg.color,
              background: cfg.bg,
              padding: "2px 6px",
              borderRadius: 3,
              fontWeight: 700,
              letterSpacing: "0.05em",
            }}
          >
            {node.state}
          </span>
        </span>
      </div>

      {/* Narrative */}
      <p
        style={{
          fontSize: 11,
          lineHeight: 1.55,
          color: "var(--pemali-text-secondary)",
          margin: 0,
          overflow: "hidden",
          display: "-webkit-box",
          WebkitLineClamp: 3,
          WebkitBoxOrient: "vertical",
        }}
      >
        {truncated}
      </p>

      {/* Bottom type badge */}
      <div
        style={{
          position: "absolute",
          bottom: 8,
          right: 12,
          fontSize: 9,
          color: "var(--pemali-text-muted)",
          fontFamily: "var(--font-geist-mono, monospace)",
          letterSpacing: "0.06em",
        }}
      >
        {node.node_type.toUpperCase()}
      </div>
    </div>
  );
}

// ─── SVG Edges ────────────────────────────────────────────────────────────────
function EdgeLayer({
  edges,
  nodes,
}: {
  edges: GraphEdge[];
  nodes: AgentNodeData[];
}) {
  const nodeById = useMemo(
    () => new Map(nodes.map((n) => [n.id, n])),
    [nodes]
  );

  return (
    <>
      <defs>
        <marker
          id="arrowhead"
          markerWidth="8"
          markerHeight="8"
          refX="6"
          refY="3"
          orient="auto"
        >
          <path
            d="M0,0 L0,6 L8,3 z"
            fill="var(--pemali-border)"
          />
        </marker>
      </defs>
      {edges.map((edge) => {
        const from = nodeById.get(edge.from);
        const to = nodeById.get(edge.to);
        if (!from || !to) return null;

        const x1 = from.x;
        const y1 = from.y + NODE_H;
        const x2 = to.x;
        const y2 = to.y;
        const cy = (y1 + y2) / 2;

        return (
          <path
            key={edge.id}
            d={`M ${x1} ${y1} C ${x1} ${cy}, ${x2} ${cy}, ${x2} ${y2}`}
            stroke="var(--pemali-border)"
            strokeWidth="1.5"
            fill="none"
            markerEnd="url(#arrowhead)"
          />
        );
      })}
    </>
  );
}

// ─── Main DAGCanvas ───────────────────────────────────────────────────────────
export default function DAGCanvas() {
  const events = useTelemetryStore((s) => s.events);
  const selectedNodeId = useTelemetryStore((s) => s.selectedNodeId);
  const setSelectedNodeId = useTelemetryStore((s) => s.setSelectedNodeId);

  const { nodes, edges } = useMemo(() => buildGraph(events), [events]);

  const handleNodeClick = useCallback(
    (id: string) => {
      setSelectedNodeId(selectedNodeId === id ? null : id);
    },
    [selectedNodeId, setSelectedNodeId]
  );

  if (nodes.length === 0) {
    return (
      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 12,
          color: "var(--pemali-text-muted)",
        }}
      >
        <span style={{ fontSize: 32, opacity: 0.3 }}>⬡</span>
        <span style={{ fontSize: 12, fontFamily: "var(--font-geist-mono, monospace)" }}>
          Menunggu aktivitas agent...
        </span>
      </div>
    );
  }

  // Compute SVG bounds
  const minX = Math.min(...nodes.map((n) => n.x - NODE_W / 2)) - 40;
  const maxX = Math.max(...nodes.map((n) => n.x + NODE_W / 2)) + 40;
  const minY = -20;
  const maxY = Math.max(...nodes.map((n) => n.y + NODE_H)) + 40;
  const svgW = maxX - minX;
  const svgH = maxY - minY;

  return (
    <div
      style={{
        flex: 1,
        position: "relative",
        overflow: "auto",
        minHeight: 280,
      }}
    >
      <div
        style={{
          position: "relative",
          width: svgW,
          height: svgH,
          margin: "0 auto",
        }}
      >
        {/* SVG edge layer */}
        <svg
          style={{
            position: "absolute",
            top: -minY,
            left: -minX,
            width: svgW,
            height: svgH,
            overflow: "visible",
            pointerEvents: "none",
          }}
          viewBox={`${minX} ${minY} ${svgW} ${svgH}`}
        >
          <EdgeLayer edges={edges} nodes={nodes} />
        </svg>

        {/* Node layer */}
        <div
          style={{
            position: "absolute",
            top: -minY,
            left: -minX,
          }}
        >
          {nodes.map((node) => (
            <AgentNode
              key={node.id}
              node={node}
              isSelected={selectedNodeId === node.id}
              onClick={() => handleNodeClick(node.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
