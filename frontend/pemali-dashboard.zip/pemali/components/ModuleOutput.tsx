"use client";

import React, { useMemo } from "react";
import ReactMarkdown from "react-markdown";
import { useTelemetryStore } from "@/store/telemetryStore";

// Simple JSON syntax highlighter
function JsonView({ data }: { data: unknown }) {
  const highlighted = useMemo(() => {
    const json = JSON.stringify(data, null, 2);
    return json.replace(
      /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
      (match) => {
        let color = "#D4956A"; // number — terracotta
        if (/^"/.test(match)) {
          if (/:$/.test(match)) {
            color = "#8C9E7A"; // key — green
          } else {
            color = "#9B9690"; // string value — muted
          }
        } else if (/true|false/.test(match)) {
          color = "#8A9598"; // boolean — blue-gray
        } else if (/null/.test(match)) {
          color = "#B07068"; // null — red
        }
        return `<span style="color:${color}">${match}</span>`;
      }
    );
  }, [data]);

  return (
    <pre
      style={{
        fontSize: 11,
        fontFamily: "var(--font-geist-mono, monospace)",
        lineHeight: 1.7,
        margin: 0,
        overflowX: "auto",
        whiteSpace: "pre-wrap",
        wordBreak: "break-all",
        color: "var(--pemali-text-secondary)",
      }}
      dangerouslySetInnerHTML={{ __html: highlighted }}
    />
  );
}

// Markdown styles
const markdownComponents = {
  h1: ({ children }: { children?: React.ReactNode }) => (
    <h1
      style={{
        fontSize: 20,
        fontFamily: "'Lora', Georgia, serif",
        fontWeight: 600,
        color: "var(--pemali-text-primary)",
        marginBottom: 8,
        marginTop: 20,
        letterSpacing: "-0.01em",
        lineHeight: 1.3,
      }}
    >
      {children}
    </h1>
  ),
  h2: ({ children }: { children?: React.ReactNode }) => (
    <h2
      style={{
        fontSize: 14,
        fontWeight: 600,
        color: "var(--pemali-text-primary)",
        marginBottom: 6,
        marginTop: 16,
        letterSpacing: "0.01em",
        textTransform: "uppercase" as const,
        fontFamily: "var(--font-geist-mono, monospace)",
        fontSize2: 11,
      }}
    >
      {children}
    </h2>
  ),
  h3: ({ children }: { children?: React.ReactNode }) => (
    <h3
      style={{
        fontSize: 13,
        fontWeight: 600,
        color: "var(--pemali-text-secondary)",
        marginBottom: 4,
        marginTop: 12,
      }}
    >
      {children}
    </h3>
  ),
  p: ({ children }: { children?: React.ReactNode }) => (
    <p
      style={{
        fontSize: 13,
        lineHeight: 1.7,
        color: "var(--pemali-text-secondary)",
        marginBottom: 8,
        marginTop: 0,
      }}
    >
      {children}
    </p>
  ),
  li: ({ children }: { children?: React.ReactNode }) => (
    <li
      style={{
        fontSize: 13,
        lineHeight: 1.65,
        color: "var(--pemali-text-secondary)",
        marginBottom: 3,
        paddingLeft: 4,
      }}
    >
      {children}
    </li>
  ),
  ul: ({ children }: { children?: React.ReactNode }) => (
    <ul
      style={{
        paddingLeft: 18,
        marginBottom: 8,
        marginTop: 0,
      }}
    >
      {children}
    </ul>
  ),
  ol: ({ children }: { children?: React.ReactNode }) => (
    <ol
      style={{
        paddingLeft: 18,
        marginBottom: 8,
        marginTop: 0,
      }}
    >
      {children}
    </ol>
  ),
  strong: ({ children }: { children?: React.ReactNode }) => (
    <strong style={{ fontWeight: 600, color: "var(--pemali-text-primary)" }}>
      {children}
    </strong>
  ),
  code: ({ children }: { children?: React.ReactNode }) => (
    <code
      style={{
        fontSize: 11,
        fontFamily: "var(--font-geist-mono, monospace)",
        background: "rgba(212,149,106,0.08)",
        color: "#D4956A",
        padding: "1px 5px",
        borderRadius: 3,
      }}
    >
      {children}
    </code>
  ),
};

export default function ModuleOutput() {
  const finalReport = useTelemetryStore((s) => s.finalReport);
  const events = useTelemetryStore((s) => s.events);

  // Gather module tool results (non-final)
  const moduleResults = useMemo(() => {
    return events.filter(
      (e) =>
        e.node_type === "Module" &&
        e.state === "DONE" &&
        e.metadata?.tool_name
    );
  }, [events]);

  if (!finalReport && moduleResults.length === 0) {
    return (
      <div
        style={{
          padding: "20px 16px",
          color: "var(--pemali-text-muted)",
          fontSize: 11,
          fontFamily: "var(--font-geist-mono, monospace)",
          textAlign: "center",
        }}
      >
        Output modul akan muncul di sini
      </div>
    );
  }

  return (
    <div style={{ padding: "14px 16px", overflow: "auto", maxHeight: "100%" }}>
      {/* Final Report */}
      {finalReport && (
        <div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              marginBottom: 14,
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "#80A888",
                display: "inline-block",
              }}
            />
            <span
              style={{
                fontSize: 9,
                fontFamily: "var(--font-geist-mono, monospace)",
                color: "#80A888",
                letterSpacing: "0.08em",
                fontWeight: 700,
              }}
            >
              LAPORAN FINAL
            </span>
          </div>
          <div>
            <ReactMarkdown components={markdownComponents as never}>
              {finalReport}
            </ReactMarkdown>
          </div>
        </div>
      )}

      {/* Module results */}
      {!finalReport && moduleResults.length > 0 && (
        <div>
          <div
            style={{
              fontSize: 9,
              color: "var(--pemali-text-muted)",
              fontFamily: "var(--font-geist-mono, monospace)",
              letterSpacing: "0.08em",
              marginBottom: 10,
            }}
          >
            OUTPUT MODUL ({moduleResults.length})
          </div>
          {moduleResults.map((ev, i) => (
            <div
              key={i}
              style={{
                marginBottom: 10,
                borderLeft: "2px solid #7A9A78",
                paddingLeft: 10,
              }}
            >
              <div
                style={{
                  fontSize: 10,
                  fontFamily: "var(--font-geist-mono, monospace)",
                  color: "#7A9A78",
                  marginBottom: 4,
                }}
              >
                {String(ev.metadata?.tool_name ?? ev.node_id)}
                {ev.metadata?.duration_ms !== undefined && (
                  <span style={{ color: "var(--pemali-text-muted)", marginLeft: 8 }}>
                    {Number(ev.metadata.duration_ms).toFixed(0)}ms
                  </span>
                )}
              </div>
              <p
                style={{
                  fontSize: 11,
                  color: "var(--pemali-text-secondary)",
                  margin: 0,
                  lineHeight: 1.6,
                }}
              >
                {ev.narrative}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
