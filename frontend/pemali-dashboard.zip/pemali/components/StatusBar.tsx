"use client";

import React from "react";
import { useTelemetryStore } from "@/store/telemetryStore";

export default function StatusBar({ model = "deepseek-r1" }: { model?: string }) {
  const isConnected = useTelemetryStore((s) => s.isConnected);
  const isStreaming = useTelemetryStore((s) => s.isStreaming);
  const events = useTelemetryStore((s) => s.events);
  const activeTraceId = useTelemetryStore((s) => s.activeTraceId);

  const workerStatus = isStreaming ? "processing" : isConnected ? "connected" : "standby";
  const workerColor = isStreaming ? "#D4956A" : isConnected ? "#80A888" : "#9B9690";

  return (
    <div
      style={{
        height: 36,
        borderBottom: "1px solid var(--pemali-border)",
        display: "flex",
        alignItems: "center",
        paddingLeft: 16,
        paddingRight: 16,
        gap: 20,
        flexShrink: 0,
        background: "var(--pemali-bg)",
      }}
    >
      {/* Logo */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 7,
        }}
      >
        <span
          style={{
            fontSize: 13,
            color: "var(--pemali-accent)",
            letterSpacing: "-0.02em",
          }}
        >
          ⬡
        </span>
        <span
          style={{
            fontSize: 12,
            fontFamily: "'Lora', Georgia, serif",
            fontWeight: 600,
            color: "var(--pemali-text-primary)",
            letterSpacing: "0.03em",
          }}
        >
          PEMALI
        </span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 16, background: "var(--pemali-border)" }} />

      {/* Model */}
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span
          style={{
            fontSize: 9,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-muted)",
            letterSpacing: "0.06em",
          }}
        >
          MODEL
        </span>
        <span
          style={{
            fontSize: 10,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-secondary)",
            fontWeight: 600,
          }}
        >
          {model}
        </span>
      </div>

      {/* Worker status */}
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span
          style={{
            fontSize: 9,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-muted)",
            letterSpacing: "0.06em",
          }}
        >
          WORKER
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <span
            style={{
              width: 6,
              height: 6,
              borderRadius: "50%",
              background: workerColor,
              display: "inline-block",
              animation: isStreaming ? "pemali-pulse 1.2s ease-in-out infinite" : "none",
            }}
          />
          <span
            style={{
              fontSize: 10,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: workerColor,
              fontWeight: 600,
            }}
          >
            {workerStatus}
          </span>
        </span>
      </div>

      {/* Events count */}
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span
          style={{
            fontSize: 9,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-muted)",
            letterSpacing: "0.06em",
          }}
        >
          EVENTS
        </span>
        <span
          style={{
            fontSize: 10,
            fontFamily: "var(--font-geist-mono, monospace)",
            color: "var(--pemali-text-secondary)",
            fontWeight: 600,
          }}
        >
          {events.length}
        </span>
      </div>

      {/* Trace ID */}
      {activeTraceId && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginLeft: "auto" }}>
          <span
            style={{
              fontSize: 9,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: "var(--pemali-text-muted)",
              letterSpacing: "0.06em",
            }}
          >
            TRACE
          </span>
          <span
            style={{
              fontSize: 9,
              fontFamily: "var(--font-geist-mono, monospace)",
              color: "var(--pemali-text-muted)",
            }}
          >
            {activeTraceId.slice(0, 16)}…
          </span>
        </div>
      )}
    </div>
  );
}
