"use client";

import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import ReactMarkdown from "react-markdown";
import { useTelemetryStore } from "@/store/telemetryStore";
import { useSSEStream } from "@/hooks/useSSEStream";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  nodeId?: string;
  timestamp: number;
}

// Shared markdown components for chat
const mdComponents = {
  p: ({ children }: { children?: React.ReactNode }) => (
    <p style={{ margin: "0 0 6px 0", lineHeight: 1.65 }}>{children}</p>
  ),
  code: ({ children }: { children?: React.ReactNode }) => (
    <code
      style={{
        fontSize: "0.88em",
        fontFamily: "var(--font-geist-mono, monospace)",
        background: "rgba(212,149,106,0.10)",
        color: "#D4956A",
        padding: "1px 4px",
        borderRadius: 3,
      }}
    >
      {children}
    </code>
  ),
  strong: ({ children }: { children?: React.ReactNode }) => (
    <strong style={{ fontWeight: 600 }}>{children}</strong>
  ),
};

export default function ChatPanel() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const tokens = useTelemetryStore((s) => s.tokens);
  const isStreaming = useTelemetryStore((s) => s.isStreaming);
  const events = useTelemetryStore((s) => s.events);
  const { startStream } = useSSEStream();

  // When Manager DONE without final_report → treat as chat response
  useEffect(() => {
    const lastManagerDone = [...events]
      .reverse()
      .find(
        (e) =>
          e.node_id === "manager" &&
          e.state === "DONE" &&
          e.metadata?.type !== "final_report"
      );
    if (lastManagerDone) {
      setMessages((prev) => {
        const alreadyAdded = prev.some(
          (m) =>
            m.role === "assistant" &&
            m.content === lastManagerDone.narrative &&
            m.nodeId === "manager"
        );
        if (alreadyAdded) return prev;
        return [
          ...prev,
          {
            id: `msg-${Date.now()}-manager-done`,
            role: "assistant",
            content: lastManagerDone.narrative,
            nodeId: "manager",
            timestamp: lastManagerDone.timestamp * 1000,
          },
        ];
      });
    }
  }, [events]);

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, tokens]);

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 120) + "px";
  }, [input]);

  const handleSubmit = useCallback(async () => {
    const text = input.trim();
    if (!text || isStreaming) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    await startStream(text);
  }, [input, isStreaming, startStream]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    },
    [handleSubmit]
  );

  // Active token entries
  const activeTokens = useMemo(
    () => Object.entries(tokens).filter(([, text]) => text.length > 0),
    [tokens]
  );

  const hasContent = messages.length > 0 || (isStreaming && activeTokens.length > 0);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        overflow: "hidden",
      }}
    >
      {/* Messages area */}
      <div
        style={{
          flex: 1,
          overflowY: "auto",
          padding: "16px 16px 0 16px",
        }}
      >
        {!hasContent && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              paddingTop: 40,
              gap: 10,
              color: "var(--pemali-text-muted)",
            }}
          >
            <span style={{ fontSize: 28, opacity: 0.25 }}>⬡</span>
            <span
              style={{
                fontSize: 11,
                fontFamily: "var(--font-geist-mono, monospace)",
                textAlign: "center",
                lineHeight: 1.7,
              }}
            >
              Mulai audit lingkungan atau<br />ajukan pertanyaan ke PEMALI
            </span>
          </div>
        )}

        {/* Message list */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.map((msg) => (
            <div
              key={msg.id}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: msg.role === "user" ? "flex-end" : "flex-start",
              }}
            >
              {msg.role === "user" ? (
                <div
                  style={{
                    background: "var(--pemali-surface)",
                    border: "1px solid var(--pemali-border)",
                    borderRadius: "10px 10px 2px 10px",
                    padding: "9px 13px",
                    maxWidth: "82%",
                    fontSize: 13,
                    color: "var(--pemali-text-primary)",
                    lineHeight: 1.6,
                  }}
                >
                  {msg.content}
                </div>
              ) : (
                <div
                  style={{
                    maxWidth: "95%",
                    borderLeft: "2px solid var(--pemali-accent)",
                    paddingLeft: 10,
                    paddingTop: 2,
                    paddingBottom: 2,
                  }}
                >
                  {msg.nodeId && (
                    <div
                      style={{
                        fontSize: 9,
                        fontFamily: "var(--font-geist-mono, monospace)",
                        color: "var(--pemali-text-muted)",
                        marginBottom: 4,
                        letterSpacing: "0.06em",
                      }}
                    >
                      {msg.nodeId}
                    </div>
                  )}
                  <div
                    style={{
                      fontSize: 13,
                      color: "var(--pemali-text-secondary)",
                      lineHeight: 1.65,
                    }}
                  >
                    <ReactMarkdown components={mdComponents as never}>
                      {msg.content}
                    </ReactMarkdown>
                  </div>
                  <div
                    style={{
                      fontSize: 9,
                      color: "var(--pemali-text-muted)",
                      marginTop: 4,
                      fontFamily: "var(--font-geist-mono, monospace)",
                    }}
                  >
                    {new Date(msg.timestamp).toLocaleTimeString("id-ID")}
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Live token streaming */}
          {isStreaming &&
            activeTokens.map(([nodeId, text]) => (
              <div
                key={nodeId}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                }}
              >
                <div
                  style={{
                    maxWidth: "95%",
                    borderLeft: "2px solid var(--pemali-accent)",
                    paddingLeft: 10,
                    paddingTop: 2,
                    paddingBottom: 2,
                    position: "relative",
                  }}
                >
                  <div
                    style={{
                      fontSize: 9,
                      fontFamily: "var(--font-geist-mono, monospace)",
                      color: "var(--pemali-accent)",
                      marginBottom: 4,
                      letterSpacing: "0.06em",
                      display: "flex",
                      alignItems: "center",
                      gap: 5,
                    }}
                  >
                    <span
                      style={{
                        width: 5,
                        height: 5,
                        borderRadius: "50%",
                        background: "var(--pemali-accent)",
                        display: "inline-block",
                        animation: "pemali-pulse 1s ease-in-out infinite",
                      }}
                    />
                    {nodeId}
                  </div>
                  <div
                    style={{
                      fontSize: 13,
                      color: "var(--pemali-text-secondary)",
                      lineHeight: 1.65,
                      fontFamily: "var(--font-geist-mono, monospace)",
                    }}
                  >
                    <ReactMarkdown components={mdComponents as never}>
                      {text}
                    </ReactMarkdown>
                    <span
                      style={{
                        display: "inline-block",
                        width: 2,
                        height: "1em",
                        background: "var(--pemali-accent)",
                        marginLeft: 2,
                        verticalAlign: "text-bottom",
                        animation: "pemali-blink 0.8s step-end infinite",
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}

          {/* Thinking indicator when streaming but no tokens yet */}
          {isStreaming && activeTokens.length === 0 && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                paddingLeft: 12,
              }}
            >
              <div style={{ display: "flex", gap: 4 }}>
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    style={{
                      width: 5,
                      height: 5,
                      borderRadius: "50%",
                      background: "var(--pemali-accent)",
                      display: "inline-block",
                      opacity: 0.5,
                      animation: `pemali-bounce 1.2s ease-in-out ${i * 0.2}s infinite`,
                    }}
                  />
                ))}
              </div>
              <span
                style={{
                  fontSize: 10,
                  color: "var(--pemali-text-muted)",
                  fontFamily: "var(--font-geist-mono, monospace)",
                }}
              >
                memproses...
              </span>
            </div>
          )}
        </div>

        <div ref={bottomRef} style={{ height: 16 }} />
      </div>

      {/* Input area */}
      <div
        style={{
          padding: "12px 16px",
          borderTop: "1px solid var(--pemali-border)",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            alignItems: "flex-end",
            background: "var(--pemali-surface)",
            border: "1px solid var(--pemali-border)",
            borderRadius: 10,
            padding: "8px 10px",
            transition: "border-color 0.15s ease",
          }}
          onFocus={() => {}}
        >
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isStreaming}
            placeholder={
              isStreaming
                ? "Menunggu respons..."
                : "Mulai audit atau tanya sesuatu..."
            }
            rows={1}
            style={{
              flex: 1,
              background: "none",
              border: "none",
              outline: "none",
              resize: "none",
              fontSize: 13,
              color: "var(--pemali-text-primary)",
              fontFamily: "inherit",
              lineHeight: 1.5,
              minHeight: 22,
              maxHeight: 120,
              overflowY: "auto",
            }}
          />
          <button
            onClick={handleSubmit}
            disabled={!input.trim() || isStreaming}
            style={{
              width: 30,
              height: 30,
              borderRadius: 7,
              border: "none",
              background:
                input.trim() && !isStreaming
                  ? "var(--pemali-accent)"
                  : "var(--pemali-border)",
              color: input.trim() && !isStreaming ? "#fff" : "var(--pemali-text-muted)",
              cursor: input.trim() && !isStreaming ? "pointer" : "not-allowed",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 14,
              transition: "all 0.15s ease",
              flexShrink: 0,
            }}
          >
            ↑
          </button>
        </div>
        <div
          style={{
            marginTop: 5,
            fontSize: 9,
            color: "var(--pemali-text-muted)",
            fontFamily: "var(--font-geist-mono, monospace)",
            paddingLeft: 2,
          }}
        >
          Enter kirim · Shift+Enter baris baru
        </div>
      </div>
    </div>
  );
}
