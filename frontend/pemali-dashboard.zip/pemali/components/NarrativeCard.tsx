"use client";

import React from "react";
import { TelemetryEvent, NodeState } from "@/types/pemali";

const STATE_COLORS: Record<NodeState, string> = {
  IDLE: "#9B9690",
  THINKING: "#D4956A",
  SPAWNING: "#8A9598",
  EXECUTING: "#7A9A78",
  DONE: "#80A888",
  ERROR: "#B07068",
};

const STATE_ICONS: Record<NodeState, string> = {
  IDLE: "○",
  THINKING: "◎",
  SPAWNING: "◈",
  EXECUTING: "▶",
  DONE: "✓",
  ERROR: "✕",
};

export default function NarrativeCard({
  event,
  isLast = false,
}: {
  event: TelemetryEvent;
  isLast?: boolean;
}) {
  const color = STATE_COLORS[event.state] ?? "#9B9690";
  const icon = STATE_ICONS[event.state] ?? "○";
  const time = new Date(event.timestamp * 1000).toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  return (
    <div
      style={{
        display: "flex",
        gap: 10,
        paddingBottom: isLast ? 0 : 12,
        animation: "pemali-slide-in 0.3s cubic-bezier(0.25, 0.1, 0.25, 1) forwards",
      }}
    >
      {/* Timeline column */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          flexShrink: 0,
          width: 20,
        }}
      >
        <div
          style={{
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: `${color}18`,
            border: `1.5px solid ${color}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 8,
            color,
            flexShrink: 0,
          }}
        >
          {icon}
        </div>
        {!isLast && (
          <div
            style={{
              width: 1,
              flex: 1,
              marginTop: 3,
              background: "var(--pemali-border)",
              minHeight: 16,
            }}
          />
        )}
      </div>

      {/* Content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Header row */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginBottom: 4,
            flexWrap: "wrap",
          }}
        >
          <span
            style={{
              fontSize: 10,
              fontFamily: "var(--font-geist-mono, monospace)",
              fontWeight: 700,
              color: "var(--pemali-text-primary)",
            }}
          >
            {event.node_id}
          </span>
          <span
            style={{
              fontSize: 8,
              fontFamily: "var(--font-geist-mono, monospace)",
              color,
              background: `${color}15`,
              padding: "1px 5px",
              borderRadius: 3,
              fontWeight: 700,
              letterSpacing: "0.04em",
            }}
          >
            {event.state}
          </span>
          <span
            style={{
              fontSize: 9,
              color: "var(--pemali-text-muted)",
              fontFamily: "var(--font-geist-mono, monospace)",
              marginLeft: "auto",
            }}
          >
            {time}
          </span>
        </div>

        {/* Narrative */}
        <p
          style={{
            fontSize: 11,
            color: "var(--pemali-text-secondary)",
            margin: "0 0 4px 0",
            lineHeight: 1.6,
          }}
        >
          {event.narrative}
        </p>

        {/* Metadata chips */}
        {event.metadata && (
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {Object.entries(event.metadata).map(([k, v]) => (
              <span
                key={k}
                style={{
                  fontSize: 9,
                  fontFamily: "var(--font-geist-mono, monospace)",
                  color: "var(--pemali-text-muted)",
                  background: "var(--pemali-surface)",
                  padding: "1px 5px",
                  borderRadius: 3,
                  border: "1px solid var(--pemali-border)",
                }}
              >
                {k}: {String(v)}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
