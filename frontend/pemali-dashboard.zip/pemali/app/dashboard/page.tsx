"use client";

import React, { useState } from "react";
import StatusBar from "@/components/StatusBar";
import Sidebar from "@/components/Sidebar";
import DAGCanvas from "@/components/DAGCanvas";
import NodeDetailPanel from "@/components/NodeDetailPanel";
import ModuleOutput from "@/components/ModuleOutput";
import ChatPanel from "@/components/ChatPanel";
import { useTelemetryStore } from "@/store/telemetryStore";

type ObservationTab = "dag" | "detail" | "output";

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [obsTab, setObsTab] = useState<ObservationTab>("dag");
  const selectedNodeId = useTelemetryStore((s) => s.selectedNodeId);
  const finalReport = useTelemetryStore((s) => s.finalReport);

  // Auto-switch to detail when node selected
  React.useEffect(() => {
    if (selectedNodeId) setObsTab("detail");
  }, [selectedNodeId]);

  // Auto-switch to output when final report arrives
  React.useEffect(() => {
    if (finalReport) setObsTab("output");
  }, [finalReport]);

  return (
    <div
      style={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        background: "var(--pemali-bg)",
        overflow: "hidden",
      }}
    >
      {/* Status Bar */}
      <StatusBar />

      {/* Main content */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        {/* Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen((v) => !v)}
        />

        {/* Observation Zone */}
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            borderRight: "1px solid var(--pemali-border)",
            overflow: "hidden",
            minWidth: 0,
          }}
        >
          {/* Observation Zone Header */}
          <div
            style={{
              height: 38,
              borderBottom: "1px solid var(--pemali-border)",
              display: "flex",
              alignItems: "stretch",
              flexShrink: 0,
              paddingLeft: 16,
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 4,
                marginRight: 16,
              }}
            >
              <span
                style={{
                  fontSize: 9,
                  fontFamily: "var(--font-geist-mono, monospace)",
                  color: "var(--pemali-text-muted)",
                  letterSpacing: "0.08em",
                }}
              >
                OBSERVATION ZONE
              </span>
            </div>
            {(
              [
                { id: "dag", label: "DAG" },
                { id: "detail", label: "Detail" },
                { id: "output", label: "Output" },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setObsTab(tab.id)}
                style={{
                  padding: "0 14px",
                  background: "none",
                  border: "none",
                  borderBottom:
                    obsTab === tab.id
                      ? "2px solid var(--pemali-accent)"
                      : "2px solid transparent",
                  cursor: "pointer",
                  fontSize: 11,
                  fontFamily: "var(--font-geist-mono, monospace)",
                  color:
                    obsTab === tab.id
                      ? "var(--pemali-text-primary)"
                      : "var(--pemali-text-muted)",
                  fontWeight: obsTab === tab.id ? 600 : 400,
                  letterSpacing: "0.03em",
                  transition: "all 0.15s ease",
                }}
              >
                {tab.label}
                {tab.id === "detail" && selectedNodeId && (
                  <span
                    style={{
                      marginLeft: 4,
                      width: 5,
                      height: 5,
                      borderRadius: "50%",
                      background: "var(--pemali-accent)",
                      display: "inline-block",
                      verticalAlign: "middle",
                    }}
                  />
                )}
                {tab.id === "output" && finalReport && (
                  <span
                    style={{
                      marginLeft: 4,
                      width: 5,
                      height: 5,
                      borderRadius: "50%",
                      background: "#80A888",
                      display: "inline-block",
                      verticalAlign: "middle",
                    }}
                  />
                )}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div
            style={{
              flex: 1,
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {obsTab === "dag" && <DAGCanvas />}
            {obsTab === "detail" && <NodeDetailPanel />}
            {obsTab === "output" && (
              <div style={{ flex: 1, overflow: "auto" }}>
                <ModuleOutput />
              </div>
            )}
          </div>
        </div>

        {/* Interaction Zone */}
        <div
          style={{
            width: "38%",
            minWidth: 300,
            maxWidth: 520,
            flexShrink: 0,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          {/* Interaction Zone Header */}
          <div
            style={{
              height: 38,
              borderBottom: "1px solid var(--pemali-border)",
              display: "flex",
              alignItems: "center",
              paddingLeft: 16,
              flexShrink: 0,
            }}
          >
            <span
              style={{
                fontSize: 9,
                fontFamily: "var(--font-geist-mono, monospace)",
                color: "var(--pemali-text-muted)",
                letterSpacing: "0.08em",
              }}
            >
              INTERACTION ZONE
            </span>
          </div>

          {/* Chat Panel */}
          <div style={{ flex: 1, overflow: "hidden" }}>
            <ChatPanel />
          </div>
        </div>
      </div>
    </div>
  );
}
