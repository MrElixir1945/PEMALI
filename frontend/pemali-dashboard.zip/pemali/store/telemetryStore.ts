"use client";

import { create } from "zustand";
import { TelemetryEvent, Session } from "@/types/pemali";

const MAX_EVENTS = 200;

interface TelemetryStore {
  // Core state
  events: TelemetryEvent[];
  tokens: Record<string, string>;
  isConnected: boolean;
  isStreaming: boolean;
  activeTraceId: string | null;
  finalReport: string | null;

  // Session management
  sessions: Session[];
  activeSessionId: string | null;

  // Selected node for detail panel
  selectedNodeId: string | null;

  // Actions
  addEvent: (event: TelemetryEvent) => void;
  addToken: (nodeId: string, content: string) => void;
  clearTokens: () => void;
  clearEvents: () => void;
  setConnected: (status: boolean) => void;
  setActiveTraceId: (id: string | null) => void;
  setIsStreaming: (val: boolean) => void;
  setFinalReport: (report: string | null) => void;
  setSelectedNodeId: (id: string | null) => void;
  createSession: (label: string) => Session;
  setActiveSession: (id: string) => void;
  updateSessionStatus: (id: string, status: Session["status"]) => void;
}

export const useTelemetryStore = create<TelemetryStore>((set, get) => ({
  events: [],
  tokens: {},
  isConnected: false,
  isStreaming: false,
  activeTraceId: null,
  finalReport: null,
  sessions: [],
  activeSessionId: null,
  selectedNodeId: null,

  addEvent: (event) => {
    set((state) => {
      const events = [...state.events, event];
      if (events.length > MAX_EVENTS) events.shift();

      // Detect final report
      let finalReport = state.finalReport;
      if (
        event.node_id === "manager" &&
        event.state === "DONE" &&
        (event.metadata as Record<string, unknown>)?.type === "final_report"
      ) {
        finalReport = event.narrative;
      }

      // Update session status
      let sessions = state.sessions;
      if (event.node_id === "manager" && event.state === "DONE") {
        sessions = sessions.map((s) =>
          s.traceId === event.trace_id ? { ...s, status: "done" } : s
        );
      }
      if (event.state === "ERROR" && event.node_id === "manager") {
        sessions = sessions.map((s) =>
          s.traceId === event.trace_id ? { ...s, status: "error" } : s
        );
      }

      return {
        events,
        finalReport,
        sessions,
        activeTraceId: event.trace_id || state.activeTraceId,
        isStreaming:
          event.node_id === "manager" && event.state === "DONE"
            ? false
            : state.isStreaming,
      };
    });
  },

  addToken: (nodeId, content) => {
    set((state) => ({
      tokens: {
        ...state.tokens,
        [nodeId]: (state.tokens[nodeId] || "") + content,
      },
      isStreaming: true,
    }));
  },

  clearTokens: () => set({ tokens: {} }),
  clearEvents: () =>
    set({ events: [], tokens: {}, finalReport: null, selectedNodeId: null }),

  setConnected: (status) => set({ isConnected: status }),
  setActiveTraceId: (id) => set({ activeTraceId: id }),
  setIsStreaming: (val) => set({ isStreaming: val }),
  setFinalReport: (report) => set({ finalReport: report }),
  setSelectedNodeId: (id) => set({ selectedNodeId: id }),

  createSession: (label) => {
    const session: Session = {
      id: `sess-${Date.now()}`,
      label,
      timestamp: Date.now(),
      traceId: null,
      status: "active",
    };
    set((state) => ({
      sessions: [session, ...state.sessions],
      activeSessionId: session.id,
      events: [],
      tokens: {},
      finalReport: null,
    }));
    return session;
  },

  setActiveSession: (id) => set({ activeSessionId: id }),

  updateSessionStatus: (id, status) =>
    set((state) => ({
      sessions: state.sessions.map((s) =>
        s.id === id ? { ...s, status } : s
      ),
    })),
}));
